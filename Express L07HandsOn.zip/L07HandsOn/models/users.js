"use strict";

module.exports = (sequelize, DataTypes) => {
  const users = sequelize.define(
    "users",
    {
      UserId: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoincrement: true,
      },

      FirstName: DataTypes.STRING,
      LastName: DataTypes.STRING,
      Email: {
        type: DataTypes.STRING,
        unique: true,
      },

      Username: {
        type: DataTypes.STRING,
        unique: true,
      },

      Password: DataTypes.STRING,
      createdAt: DataTypes.DATE,
      updatedAt: DataTypes.DATE,

      Admin: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
      },
    },
    {}
  );

  users.associate = function (models) {};

  return users;
};
